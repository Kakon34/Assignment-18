import React from 'react';

const App = () => {
  return (
    <div>
      <p>Mern Ecommerce projects</p>
    </div>
  );
};

export default App;