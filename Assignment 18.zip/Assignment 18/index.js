const app=require("./app");
const PORT=5020;
app.listen(PORT,function () {
    console.log("App Run Success @5020....")
});
